// menu.js

const API_BASE = "https://aliceblue-dugong-485457.hostingersite.com/api";


document.addEventListener("DOMContentLoaded", function () {
  const hamburger = document.getElementById("hamburger");
  const nav = document.getElementById("mobileNav");

  if (!hamburger || !nav) {
    console.error("Hamburger or nav missing");
    return;
  }

  hamburger.addEventListener("click", function (e) {
    e.preventDefault();
    e.stopPropagation();
    nav.classList.toggle("open");
    console.log("Menu toggled:", nav.classList.contains("open"));
  });

  document.addEventListener("click", function () {
    nav.classList.remove("open");
  });

  nav.addEventListener("click", function (e) {
    e.stopPropagation();
  });
});
