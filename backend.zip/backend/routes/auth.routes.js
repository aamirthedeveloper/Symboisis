import express from "express";
import { sendOTP, verifyOTP } from "../controllers/otp.controller.js";
import { loginWithPassword } from "../controllers/password.controller.js";

const router = express.Router();

router.post("/send-otp", sendOTP);
router.post("/verify-otp", verifyOTP);
router.post("/login", loginWithPassword);

router.get("/google",
  passport.authenticate("google", { scope: ["email", "profile"] })
);

router.get("/google/callback",
  passport.authenticate("google", { session: false }),
  (req, res) => {
    // link or create user here
    res.redirect("/index.html");
  }
);


router.post("/apple", async (req, res) => {
  const { id_token } = req.body;
  // verify with Apple
  // link user
  res.json({ success: true });
});



export default router;
