export const otps = [];
