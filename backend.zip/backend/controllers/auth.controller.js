import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { users } from "../models/User.js";
import { generateOTP, hashOTP } from "../services/otp.service.js";

export async function sendOTP(req, res) {
  const { email, mobile } = req.body;
  const otp = generateOTP();

  console.log("OTP (demo):", otp); // SMS / Email later

  res.json({ success: true, message: "OTP sent" });
}

export async function login(req, res) {
  const { email, password } = req.body;
  const user = users.find(u => u.email === email);

  if (!user) return res.status(404).json({ message: "User not found" });

  const match = await bcrypt.compare(password, user.password);
  if (!match) return res.status(401).json({ message: "Invalid password" });

  const token = jwt.sign({ id: user.id }, "SECRET", { expiresIn: "1h" });

  res.json({ token });
}
