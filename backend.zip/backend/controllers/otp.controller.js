import crypto from "crypto";
import { otps } from "../models/OtpStore.js";
import { users } from "../models/User.js";

export function sendOTP(req, res) {
  const { email, mobile, purpose } = req.body;
  const otp = Math.floor(100000 + Math.random() * 900000).toString();

  const hash = crypto.createHash("sha256").update(otp).digest("hex");

  otps.push({
    email,
    mobile,
    hash,
    purpose,
    expiresAt: Date.now() + 5 * 60 * 1000
  });

  console.log("OTP (demo):", otp);

  res.json({ success: true, message: "OTP sent" });
}

export function verifyOTP(req, res) {
  const { email, mobile, otp, purpose } = req.body;

  const hash = crypto.createHash("sha256").update(otp).digest("hex");

  const record = otps.find(
    o =>
      o.hash === hash &&
      o.purpose === purpose &&
      (o.email === email || o.mobile === mobile) &&
      o.expiresAt > Date.now()
  );

  if (!record) {
    return res.status(400).json({ message: "Invalid or expired OTP" });
  }

  // Auto-create user on signup
  let user = users.find(u => u.email === email || u.mobile === mobile);
  if (!user) {
    user = { id: crypto.randomUUID(), email, mobile };
    users.push(user);
  }

  res.json({ success: true, user });
}
