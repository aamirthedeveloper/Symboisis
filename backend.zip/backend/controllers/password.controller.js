import bcrypt from "bcrypt";
import crypto from "crypto";
import { users } from "../models/User.js";

export async function resetPassword(req, res) {
  const { email, newPassword } = req.body;

  const user = users.find(u => u.email === email);
  if (!user) return res.status(404).json({ message: "User not found" });

  user.password = await bcrypt.hash(newPassword, 10);

  res.json({ success: true, message: "Password reset successful" });
}

export async function loginWithPassword(req, res) {
  const { email, password } = req.body;

  const user = users.find(u => u.email === email);
  if (!user || !user.password)
    return res.status(401).json({ message: "Invalid login" });

  const match = await bcrypt.compare(password, user.password);
  if (!match) return res.status(401).json({ message: "Wrong password" });

  res.json({ success: true, user });
}
