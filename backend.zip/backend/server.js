import express from "express";
import cors from "cors";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { v4 as uuid } from "uuid";

const app = express();
// app.use(cors());
app.use(cors({
  origin: "*", // later replace with your frontend domain
  credentials: true
}));

app.use(express.json());

// const SECRET = "SYMBOISIS_SECRET";

const SECRET = process.env.JWT_SECRET || "dev_secret";


/* ================= IN-MEMORY STORES ================= */
const users = [];   // later → database
const otps = [];    // {email, mobile, emailOtp, mobileOtp, purpose, exp}

/* ================= HELPERS ================= */
function generateOtp() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

function auth(req, res, next) {
  const h = req.headers.authorization;
  if (!h) return res.status(401).json({ message: "No token" });

  try {
    req.user = jwt.verify(h.split(" ")[1], SECRET);
    next();
  } catch {
    res.status(401).json({ message: "Invalid token" });
  }
}

/* ================= SIGNUP ================= */
app.post("/auth/signup", async (req, res) => {
  const { name, email, mobile, password } = req.body;

  if (users.find(u => u.email === email || u.mobile === mobile)) {
    return res.status(400).json({ message: "User already exists" });
  }

  const hashed = await bcrypt.hash(password, 10);

  users.push({
    id: uuid(),
    name,
    email,
    mobile,
    password: hashed,
    verified: false
  });

  res.json({ success: true });
});

/* ================= SEND OTP ================= */
app.post("/auth/send-otp", (req, res) => {
  const { email, mobile, purpose } = req.body;

  const emailOtp = generateOtp();
  const mobileOtp = generateOtp();

  otps.push({
    email,
    mobile,
    emailOtp,
    mobileOtp,
    purpose,
    exp: Date.now() + 5 * 60 * 1000
  });

  console.log("EMAIL OTP:", emailOtp);
  console.log("MOBILE OTP:", mobileOtp);

  res.json({ success: true });
});

/* ================= VERIFY OTP ================= */
app.post("/auth/verify-otp", (req, res) => {
  const { email, mobile, emailOtp, mobileOtp, purpose } = req.body;

  const record = otps.find(o =>
    o.email === email &&
    o.mobile === mobile &&
    o.emailOtp === emailOtp &&
    o.mobileOtp === mobileOtp &&
    o.purpose === purpose &&
    o.exp > Date.now()
  );

  if (!record) {
    return res.status(400).json({ message: "Invalid or expired OTP" });
  }

  const user = users.find(u => u.email === email && u.mobile === mobile);
  if (!user) return res.status(404).json({ message: "User not found" });

  user.verified = true;

  const token = jwt.sign({ id: user.id }, SECRET, { expiresIn: "1h" });
  res.json({ token });
});

/* ================= LOGIN (PASSWORD) ================= */
app.post("/auth/login", async (req, res) => {
  const { identifier, password } = req.body;

  const user = users.find(
    u => u.email === identifier || u.mobile === identifier
  );

  if (!user || !user.verified) {
    return res.status(400).json({ message: "Invalid login" });
  }

  const ok = await bcrypt.compare(password, user.password);
  if (!ok) return res.status(400).json({ message: "Wrong password" });

  const token = jwt.sign({ id: user.id }, SECRET, { expiresIn: "1h" });
  res.json({ token });
});

/* ================= LOGIN BY OTP ================= */
app.post("/auth/login-otp", (req, res) => {
  const { email, mobile, emailOtp, mobileOtp } = req.body;

  const record = otps.find(o =>
    o.email === email &&
    o.mobile === mobile &&
    o.emailOtp === emailOtp &&
    o.mobileOtp === mobileOtp &&
    o.exp > Date.now()
  );

  if (!record) return res.status(400).json({ message: "Invalid OTP" });

  const user = users.find(u => u.email === email && u.mobile === mobile);
  if (!user) return res.status(404).json({ message: "User not found" });

  const token = jwt.sign({ id: user.id }, SECRET, { expiresIn: "1h" });
  res.json({ token });
});

/* ================= FORGOT PASSWORD ================= */
app.post("/auth/reset-password", async (req, res) => {
  const { email, mobile, newPassword } = req.body;

  const user = users.find(
    u => u.email === email || u.mobile === mobile
  );
  if (!user) return res.status(404).json({ message: "User not found" });

  user.password = await bcrypt.hash(newPassword, 10);
  res.json({ success: true });
});

/* ================= SESSION CHECK ================= */
app.get("/auth/me", auth, (req, res) => {
  res.json({ ok: true });
});

/* ================= START ================= */
// app.listen(4000, () =>
//   console.log("Auth backend running on http://localhost:4000")
// );


const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`Auth backend running on port ${PORT}`);
});
